package com.byted.camp.todolist;

import android.os.Bundle;
import android.widget.EditText;
import android.widget.TextView;

import androidx.annotation.Nullable;
import androidx.appcompat.app.AppCompatActivity;

public class ItemActivity extends AppCompatActivity {
    private EditText item_content;
    private EditText item_title;
    private EditText item_filename;
    private TextView item_state;
    private TextView item_priority;
    private TextView item_tag;
    private TextView item_scheduled_date;
    private TextView item_deadline_date;
    private TextView item_show_date;


    @Override
    protected void onCreate(@Nullable Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_item);

        item_content = findViewById(R.id.item_content);
        item_title = findViewById(R.id.item_title);
        item_filename = findViewById(R.id.item_filename);
        item_state = findViewById(R.id.item_stage);
        item_priority = findViewById(R.id.item_priority);
        item_tag = findViewById(R.id.item_tag);
        item_scheduled_date = findViewById(R.id.item_sheduled_date);
        item_deadline_date = findViewById(R.id.item_deadline_date);
        item_show_date = findViewById(R.id.item_show_date);

    }
}
